#include <stdio.h>

// declararea procedurii ASM
void afisare(int);


int main()
{
    int n = 10;
    afisare(n);     // apelul procedurii ASM
    
    return 0;
}